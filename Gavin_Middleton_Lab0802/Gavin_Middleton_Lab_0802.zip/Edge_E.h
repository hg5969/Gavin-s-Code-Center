#pragma once
#include <iostream>
#include "Edge.h"
using namespace std;


class Edge_E : public Edge {
public:
	float getDistance() const;
};