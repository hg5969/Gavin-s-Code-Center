#pragma once
#include <iostream>
#include "Edge.h"
using namespace std;


class Edge_M : public Edge {
public:
	float getDistance() const;
};