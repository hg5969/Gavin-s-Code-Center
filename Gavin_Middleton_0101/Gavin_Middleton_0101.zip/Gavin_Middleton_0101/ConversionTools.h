#pragma once

float FtoC(float far);

float CtoF(float cel);