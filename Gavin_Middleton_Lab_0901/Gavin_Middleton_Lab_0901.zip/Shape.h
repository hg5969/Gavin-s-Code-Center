#pragma once
#include <iostream>
using namespace std;


class Shape {
public:
	float getArea() const;
};