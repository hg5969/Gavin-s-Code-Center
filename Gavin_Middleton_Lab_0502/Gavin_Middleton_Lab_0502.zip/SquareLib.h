#pragma once
#include <iostream>
#include "Square.h"
using namespace std;


Square doubleLength_1(Square s);
void doubleLength_2(Square& s);
void doubleLength_3(Square* s);