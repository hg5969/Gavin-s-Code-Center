#pragma once

struct CircleStr {
    float radius, perimeter, area;
};